package com.example.battlefordentalperfection;

public class bios {
	
	public void test()
	{
		
	}

}
